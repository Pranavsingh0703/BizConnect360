import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createLeadApex from '@salesforce/apex/LeadController.createLead';

export default class LeadCapture extends LightningElement {
  name = '';
  company = '';
  email = '';

  handleChange(e) {
    const field = e.target.dataset.id;
    this[field] = e.target.value;
  }

  async createLead() {
    try {
      await createLeadApex({ lastName: this.name || 'Unknown', company: this.company || 'Individual', email: this.email });
      this.dispatchEvent(new ShowToastEvent({ title: 'Success', message: 'Lead created', variant: 'success' }));
      // clear inputs
      this.template.querySelectorAll('lightning-input').forEach(inp => inp.value = '');
    } catch (err) {
      this.dispatchEvent(new ShowToastEvent({ title: 'Error', message: err.body ? err.body.message : err.message, variant: 'error' }));
    }
  }
}
