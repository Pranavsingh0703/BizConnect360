import { LightningElement } from 'lwc';
import getTodaysVisits from '@salesforce/apex/FieldVisitController.getTodaysVisits';

export default class FieldAgentMap extends LightningElement {
  markers;

  loadVisits() {
    getTodaysVisits()
      .then(result => {
        this.markers = result.map(v => {
          const coords = (v.GPS_Location__c || '0,0').split(',');
          return {
            location: { Latitude: parseFloat(coords[0]), Longitude: parseFloat(coords[1]) },
            title: v.Name,
            description: v.Status__c
          };
        });
      })
      .catch(err => {
        console.error(err);
      });
  }
}
