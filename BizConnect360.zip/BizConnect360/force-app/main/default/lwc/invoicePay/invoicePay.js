import { LightningElement, api } from 'lwc';
import createPayment from '@salesforce/apex/PaymentService.createPaymentForInvoice';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class InvoicePay extends LightningElement {
  @api recordId;
  @api amount;

  payNow() {
    createPayment({ invoiceId: this.recordId })
      .then(res => {
        this.dispatchEvent(new ShowToastEvent({ title: 'Payment Created', message: 'Payment ref: ' + res, variant: 'success' }));
      })
      .catch(err => {
        this.dispatchEvent(new ShowToastEvent({ title: 'Error', message: err.body ? err.body.message : err.message, variant: 'error' }));
      });
  }
}
